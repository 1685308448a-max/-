# Survivalcraft 晴天控制器（APK API 对接版）

## 1. 项目功能

这是基于本次上传 APK 的运行时程序集结构编写的晴天控制器源码工程，目标方块名为 `SunWeatherControllerBlock`。

放置后对方块交互，会打开控制器界面：

- 左侧：一个燃料槽，只接受指定燃料方块。
- 中间：本次燃料的充能进度条。
- 右侧：当前晴天能量余量条。
- 能量大于 0 时，持续压制降水、闪电和雨声，使天气保持晴朗。
- 能量耗尽或控制器全部拆除后，恢复接管前的天气参数。
- 控制器位置、能量、充能进度和槽位内容会保存到世界数据中。
- 拆除控制器时，槽位里剩余的燃料会尝试掉落到方块位置。

## 2. 默认数值

参数集中在 `src/SunWeatherControllerConfig.cs`：

| 参数 | 默认值 | 作用 |
|---|---:|---|
| `FuelBlockTypeName` | `DiamondBlock` | 唯一接受的燃料方块 |
| `ChargeSecondsPerFuel` | 8 秒 | 消耗一个燃料方块所需时间 |
| `EnergyPerFuel` | 25 | 单个燃料方块增加的能量 |
| `MaxEnergy` | 100 | 能量上限 |
| `EnergyDrainPerSecond` | 0.05 | 晴天运行时每秒耗能 |
| `FuelSlotCapacity` | 64 | 单槽位堆叠上限 |

因此单个燃料方块可提供约 500 秒的晴天运行时间；四个燃料方块可将能量充至满值。实际持续时间会受游戏帧步长影响。

`DiamondBlock` 已在上传 APK 的 `assemblies/Survivalcraft.dll` 中确认存在。若移植到另一个 PC API 版本，可以在配置文件里改成该版本实际存在的方块类名。

## 3. 本次 APK 的 API 核对结果

本项目以 APK 内的 `assemblies/Survivalcraft.dll` 为目标分析对象，不以 APK 根目录下另一个同名 DLL 代替。该运行时 DLL 的 SHA-256 为 `828c9ae15957e81ae839b1fbad39e0e6317fa5b35d0e1426082352bc8d916214`。本工程因此是“本次上传 APK 的 API 对接版”，并非可直接丢进另一套 Windows PC API 1.9.3.1 的现成插件；迁移到 PC API 时需要换成目标 PC DLL 重新编译并复核天气字段。核对到的 API 包括：

- `Game.SubsystemBlockBehavior`：有 `HandledBlocks`、`OnBlockAdded(value, oldValue, x, y, z)`、`OnBlockRemoved(value, newValue, x, y, z)`、`OnBlockGenerated(value, x, y, z, isLoaded)`、`OnInteract(TerrainRaycastResult, ComponentMiner)`。
- `Game.IUpdateable`：由控制器行为实现 `UpdateOrder` 和 `Update(float)`，因此不需要额外再注册一个独立计时子系统。
- `Game.IInventory`：接口包含单槽位库存实现所需的全部成员，包括 `ProcessSlotItems` 的两个 `ref int` 参数和 `DropAllItems(Vector3)`。
- `Game.InventorySlotWidget.AssignInventorySlot`、`Game.ValueBarWidget`、`Game.CanvasWidget`、`Game.LabelWidget`、`Game.DialogsManager.ShowDialog`：用于搭建交互界面。
- `Game.SubsystemWeather` 内部字段：`m_precipitationStartTime`、`m_precipitationEndTime` 为 `double`；`m_lightningIntensity`、`m_globalPrecipitationIntensity`、`m_targetRainSoundVolume`、`m_rainVolumeFactor` 为 `float`。工程通过反射修改这些字段，并在能量耗尽时还原快照。

天气字段不是公开 API，使用反射是针对当前 APK 的实现方式。换到不同版本后，必须重新核对字段名和字段类型。

## 4. 编译

工程为 .NET Framework 4.7.2 类库。`References/` 中包含从本次 APK 提取的四个编译引用：

- `Survivalcraft.dll`
- `Engine.dll`
- `EntitySystem.dll`
- `FJCore.dll`

在装有 Visual Studio Build Tools 和 .NET Framework 4.7.2 targeting pack 的 Windows 开发者命令行中执行：

```powershell
.\Build\Build.ps1
```

预期输出：`bin/Release/net472/SunWeatherController.dll`。

## 5. 内容数据库注册

仅编译 DLL 不会自动出现新方块。必须把 `ContentPatch/` 中的片段合并到游戏的内容数据库：

1. 将 `Blocks.csv.fragment` 的数据行合并进原版 `Blocks.csv`，不要用片段文件覆盖整个 CSV。表头用于核对列顺序；本行共 74 列。
2. 将 `SubsystemTemplate.fragment.xml` 中的 `SubsystemTemplate` 节点，合并到内容数据库中已有的 `SubsystemTemplate` 列表。
3. 将 `ProjectTemplate.Member.fragment.xml` 中的 `MemberSubsystemTemplate` 节点，加入 `ProjectTemplate Name="Project"` 的成员子系统列表。
4. 重新打包 `Content.pak`，并确保运行时能加载包含 `Game.SunWeatherControllerBlock` 与 `Game.SubsystemSunWeatherControllerBlockBehavior` 的程序集。

模板父 GUID `fefb9590-4972-4893-b02a-76063611b745` 来自本次 APK 中现有 `FurnaceBlockBehavior` 模板的继承关系。片段中的三个新 GUID 已彼此对应；若目标内容库已有同 GUID，需重新生成一组唯一 GUID 并同步修改引用。

### 程序集加载的重要说明

本次 APK 有 `assemblies/HentaiEx.dll`，但仅凭现有包内容无法确认它提供了一个可供任意第三方 DLL 使用的通用插件加载契约。因此，本工程不宣称把 DLL 丢进目录就一定会自动加载。

可靠集成方式二选一：

- 将源码并入目标游戏 `Survivalcraft` 程序集后重新构建；或
- 使用目标游戏已有且已验证的程序集加载器加载 `SunWeatherController.dll`，并确认内容数据库的类型解析器可以找到外部程序集中的 `Game.*` 类型。

不要把本工程的 APK 版引用 DLL 直接覆盖 PC 游戏的 DLL。

## 6. 文件结构

```text
SunWeatherControllerProject/
├─ SunWeatherController.csproj
├─ README.md
├─ src/
│  ├─ SunWeatherControllerBlock.cs
│  ├─ SunWeatherControllerConfig.cs
│  ├─ ControllerState.cs
│  ├─ OneSlotInventory.cs
│  ├─ WeatherSnapshot.cs
│  ├─ SunWeatherControllerDialog.cs
│  └─ SubsystemSunWeatherControllerBlockBehavior.cs
├─ ContentPatch/
│  ├─ Blocks.csv.fragment
│  ├─ SubsystemTemplate.fragment.xml
│  └─ ProjectTemplate.Member.fragment.xml
├─ Build/Build.ps1
└─ References/
   ├─ Survivalcraft.dll
   ├─ Engine.dll
   ├─ EntitySystem.dll
   └─ FJCore.dll
```

## 7. 验收流程

1. 在创造模式物品列表中确认出现“晴天控制器”。
2. 放置控制器并交互，确认出现一个可放入物品的槽位、左侧充能进度条和右侧能量条。
3. 放入钻石块，等待约 8 秒，确认消耗 1 个钻石块并增加 25 能量。
4. 观察降雨/降雪和闪电是否停止；能量持续下降。
5. 能量降至 0 后，确认天气系统恢复原本的天气周期。
6. 保存并重新载入世界，检查槽位、进度与能量是否保持。
7. 拆除控制器，检查槽内余料是否掉落、天气是否恢复。

## 8. 验证边界

当前交付是针对上传 APK API 结构编写的完整源码与内容注册片段，不是已经重打包的 APK，也不是已经生成并实机运行验证的 DLL。当前执行环境没有可用的 C# 编译器/目标框架，因此本轮无法完成实际编译和游戏内运行测试。`Content.pak` 采用游戏专用资源封装，交付的是可合并片段，不是未经验证的伪造 `.pak`。

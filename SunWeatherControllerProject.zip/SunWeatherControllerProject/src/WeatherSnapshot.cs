using System;
using System.Globalization;
using System.Reflection;

namespace Game
{
    /// <summary>
    /// 记录被晴天控制器接管前的天气参数，能量耗尽或控制器拆除后恢复原值。
    /// 字段名来自用户提供 APK 的 Game.SubsystemWeather 元数据。
    /// </summary>
    internal sealed class WeatherSnapshot
    {
        public double PrecipitationStartTime;
        public double PrecipitationEndTime;
        public float LightningIntensity;
        public float GlobalPrecipitationIntensity;
        public float TargetRainSoundVolume;
        public float RainVolumeFactor;

        public static WeatherSnapshot Capture(SubsystemWeather weather)
        {
            if (weather == null)
                return null;

            try
            {
                return new WeatherSnapshot
                {
                    PrecipitationStartTime = ReadNumber(weather, "m_precipitationStartTime"),
                    PrecipitationEndTime = ReadNumber(weather, "m_precipitationEndTime"),
                    LightningIntensity = (float)ReadNumber(weather, "m_lightningIntensity"),
                    GlobalPrecipitationIntensity = (float)ReadNumber(weather, "m_globalPrecipitationIntensity"),
                    TargetRainSoundVolume = (float)ReadNumber(weather, "m_targetRainSoundVolume"),
                    RainVolumeFactor = (float)ReadNumber(weather, "m_rainVolumeFactor")
                };
            }
            catch
            {
                return null;
            }
        }

        public void Restore(SubsystemWeather weather)
        {
            if (weather == null)
                return;

            WriteNumber(weather, "m_precipitationStartTime", PrecipitationStartTime);
            WriteNumber(weather, "m_precipitationEndTime", PrecipitationEndTime);
            WriteNumber(weather, "m_lightningIntensity", LightningIntensity);
            WriteNumber(weather, "m_globalPrecipitationIntensity", GlobalPrecipitationIntensity);
            WriteNumber(weather, "m_targetRainSoundVolume", TargetRainSoundVolume);
            WriteNumber(weather, "m_rainVolumeFactor", RainVolumeFactor);
        }

        public static void ForceSunny(SubsystemWeather weather)
        {
            if (weather == null)
                return;

            // 两个时间点都推到 double 上限附近，阻止天气系统进入下一段降水周期。
            // 当前 APK 已核实这两个字段均为 System.Double。
            WriteNumber(weather, "m_precipitationStartTime", double.MaxValue * 0.5);
            WriteNumber(weather, "m_precipitationEndTime", double.MaxValue);

            // 当前 APK 已核实以下字段均为 System.Single。
            WriteNumber(weather, "m_lightningIntensity", 0.0);
            WriteNumber(weather, "m_globalPrecipitationIntensity", 0.0);
            WriteNumber(weather, "m_targetRainSoundVolume", 0.0);
            WriteNumber(weather, "m_rainVolumeFactor", 0.0);
        }

        public string Serialize()
        {
            return string.Join(",", new string[]
            {
                PrecipitationStartTime.ToString("R", CultureInfo.InvariantCulture),
                PrecipitationEndTime.ToString("R", CultureInfo.InvariantCulture),
                LightningIntensity.ToString("R", CultureInfo.InvariantCulture),
                GlobalPrecipitationIntensity.ToString("R", CultureInfo.InvariantCulture),
                TargetRainSoundVolume.ToString("R", CultureInfo.InvariantCulture),
                RainVolumeFactor.ToString("R", CultureInfo.InvariantCulture)
            });
        }

        public static WeatherSnapshot TryParse(string text)
        {
            if (string.IsNullOrEmpty(text))
                return null;

            string[] parts = text.Split(',');
            if (parts.Length != 6)
                return null;

            WeatherSnapshot snapshot = new WeatherSnapshot();
            if (!double.TryParse(parts[0], NumberStyles.Float, CultureInfo.InvariantCulture, out snapshot.PrecipitationStartTime) ||
                !double.TryParse(parts[1], NumberStyles.Float, CultureInfo.InvariantCulture, out snapshot.PrecipitationEndTime) ||
                !float.TryParse(parts[2], NumberStyles.Float, CultureInfo.InvariantCulture, out snapshot.LightningIntensity) ||
                !float.TryParse(parts[3], NumberStyles.Float, CultureInfo.InvariantCulture, out snapshot.GlobalPrecipitationIntensity) ||
                !float.TryParse(parts[4], NumberStyles.Float, CultureInfo.InvariantCulture, out snapshot.TargetRainSoundVolume) ||
                !float.TryParse(parts[5], NumberStyles.Float, CultureInfo.InvariantCulture, out snapshot.RainVolumeFactor))
                return null;

            return snapshot;
        }

        private static double ReadNumber(object target, string fieldName)
        {
            FieldInfo field = typeof(SubsystemWeather).GetField(
                fieldName, BindingFlags.Instance | BindingFlags.NonPublic);
            if (field == null)
                throw new MissingFieldException(typeof(SubsystemWeather).FullName, fieldName);
            return Convert.ToDouble(field.GetValue(target), CultureInfo.InvariantCulture);
        }

        private static void WriteNumber(object target, string fieldName, double value)
        {
            FieldInfo field = typeof(SubsystemWeather).GetField(
                fieldName, BindingFlags.Instance | BindingFlags.NonPublic);
            if (field == null)
                return;

            Type fieldType = field.FieldType;
            if (fieldType == typeof(double))
                field.SetValue(target, value);
            else if (fieldType == typeof(float))
                field.SetValue(target, (float)value);
            else if (fieldType == typeof(long))
                field.SetValue(target, (long)value);
            else if (fieldType == typeof(int))
                field.SetValue(target, (int)value);
        }
    }
}

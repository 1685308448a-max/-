using System;
using System.Reflection;
using Engine;

namespace Game
{
    /// <summary>
    /// 晴天控制器专用单槽位库存，只接受 Config 中指定的燃料方块。
    /// </summary>
    internal sealed class OneSlotInventory : IInventory
    {
        private readonly ControllerState m_state;
        private readonly int m_fuelContents;
        private readonly object m_subsystemPickables;
        private int m_activeSlotIndex;

        public OneSlotInventory(
            ControllerState state,
            SubsystemInventory subsystemInventory,
            int fuelContents,
            object subsystemPickables)
        {
            m_state = state;
            SubsystemInventory = subsystemInventory;
            m_fuelContents = fuelContents;
            m_subsystemPickables = subsystemPickables;
        }

        public SubsystemInventory SubsystemInventory { get; private set; }

        public int SlotsCount
        {
            get { return 1; }
        }

        public int ActiveSlotIndex
        {
            get { return m_activeSlotIndex; }
            set { m_activeSlotIndex = 0; }
        }

        public int GetSlotValue(int slotIndex)
        {
            return slotIndex == 0 ? m_state.SlotValue : 0;
        }

        public int GetSlotCount(int slotIndex)
        {
            return slotIndex == 0 ? m_state.SlotCount : 0;
        }

        public int GetSlotCapacity(int slotIndex, int value)
        {
            if (slotIndex != 0 || !IsFuel(value))
                return 0;

            if (m_state.SlotCount > 0 && Terrain.ExtractContents(m_state.SlotValue) != m_fuelContents)
                return 0;

            return SunWeatherControllerConfig.FuelSlotCapacity;
        }

        public int GetSlotProcessCapacity(int slotIndex, int value)
        {
            return GetSlotCapacity(slotIndex, value);
        }

        public void AddSlotItems(int slotIndex, int value, int count)
        {
            if (slotIndex != 0 || count <= 0 || !IsFuel(value))
                return;

            if (m_state.SlotCount > 0 && Terrain.ExtractContents(m_state.SlotValue) != m_fuelContents)
                return;

            if (m_state.SlotCount == 0)
                m_state.SlotValue = value;

            m_state.SlotCount = Math.Min(
                SunWeatherControllerConfig.FuelSlotCapacity,
                m_state.SlotCount + count);
        }

        public void ProcessSlotItems(
            int slotIndex,
            int value,
            int count,
            int processCount,
            ref int processedValue,
            ref int processedCount)
        {
            // 本库存没有二次加工输出；燃料消耗由控制器更新循环完成。
            processedValue = 0;
            processedCount = 0;
        }

        public int RemoveSlotItems(int slotIndex, int count)
        {
            if (slotIndex != 0 || count <= 0 || m_state.SlotCount <= 0)
                return 0;

            int removed = Math.Min(count, m_state.SlotCount);
            m_state.SlotCount -= removed;
            if (m_state.SlotCount == 0)
                m_state.SlotValue = 0;
            return removed;
        }

        public void DropAllItems(Vector3 position)
        {
            if (m_state.SlotCount <= 0 || m_subsystemPickables == null)
                return;

            // 使用反射调用该版本 SubsystemPickables.AddPickable，避免将不同 PC/Android API
            // 版本中的可选参数写死。当前 APK 中参数名为 value/count/position/velocity/stuckMatrix。
            try
            {
                MethodInfo method = null;
                MethodInfo[] methods = m_subsystemPickables.GetType().GetMethods(
                    BindingFlags.Public | BindingFlags.Instance);

                for (int i = 0; i < methods.Length; i++)
                {
                    if (methods[i].Name == "AddPickable" && methods[i].GetParameters().Length == 5)
                    {
                        method = methods[i];
                        break;
                    }
                }

                if (method == null)
                    return;

                ParameterInfo[] parameters = method.GetParameters();
                object[] args = new object[parameters.Length];
                int countParameterIndex = -1;

                for (int i = 0; i < parameters.Length; i++)
                {
                    string name = (parameters[i].Name ?? string.Empty).ToLowerInvariant();
                    Type parameterType = parameters[i].ParameterType;
                    Type actualType = parameterType.IsByRef ? parameterType.GetElementType() : parameterType;

                    if (name == "value")
                    {
                        args[i] = m_state.SlotValue;
                    }
                    else if (name == "count")
                    {
                        countParameterIndex = i;
                        args[i] = m_state.SlotCount;
                    }
                    else if (name == "position")
                    {
                        args[i] = position;
                    }
                    else if (parameterType.IsByRef)
                    {
                        args[i] = actualType.IsValueType ? Activator.CreateInstance(actualType) : null;
                    }
                    else if (Nullable.GetUnderlyingType(parameterType) != null || !parameterType.IsValueType)
                    {
                        args[i] = null;
                    }
                    else
                    {
                        args[i] = Activator.CreateInstance(parameterType);
                    }
                }

                method.Invoke(m_subsystemPickables, args);

                if (countParameterIndex >= 0)
                {
                    int remaining = Convert.ToInt32(args[countParameterIndex]);
                    int dropped = Math.Max(0, m_state.SlotCount - remaining);
                    RemoveSlotItems(0, dropped);
                }
            }
            catch
            {
                // 若当前游戏分支改变 AddPickable 签名，则保留槽位内容，不在失败时静默清空物品。
            }
        }

        public bool IsFuel(int value)
        {
            return value != 0 && Terrain.ExtractContents(value) == m_fuelContents;
        }

        public bool ConsumeOneFuel()
        {
            return RemoveSlotItems(0, 1) == 1;
        }
    }
}

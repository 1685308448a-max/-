using System;
using System.Reflection;
using Engine;

namespace Game
{
    /// <summary>
    /// 控制器交互界面：左侧单槽位和充能进度，右侧显示剩余晴天能量。
    /// </summary>
    internal sealed class SunWeatherControllerDialog : Dialog
    {
        private readonly ControllerState m_state;
        private readonly ValueBarWidget m_chargeBar;
        private readonly ValueBarWidget m_energyBar;
        private readonly LabelWidget m_statusLabel;
        private readonly LabelWidget m_slotCaption;

        public SunWeatherControllerDialog(ControllerState state)
        {
            m_state = state;

            CanvasWidget root = new CanvasWidget();
            root.Size = new Vector2(420.0f, 220.0f);

            LabelWidget title = new LabelWidget();
            title.Text = "晴天控制器";
            title.Size = new Vector2(360.0f, 28.0f);
            root.Children.Add(title);
            root.SetWidgetPosition(title, new Vector2(18.0f, 10.0f));

            m_slotCaption = new LabelWidget();
            m_slotCaption.Text = "燃料槽：钻石块";
            m_slotCaption.Size = new Vector2(145.0f, 24.0f);
            root.Children.Add(m_slotCaption);
            root.SetWidgetPosition(m_slotCaption, new Vector2(24.0f, 48.0f));

            InventorySlotWidget fuelSlot = new InventorySlotWidget();
            fuelSlot.Size = new Vector2(64.0f, 64.0f);
            AssignInventorySlot(fuelSlot, state.Inventory, 0);
            root.Children.Add(fuelSlot);
            root.SetWidgetPosition(fuelSlot, new Vector2(52.0f, 76.0f));

            LabelWidget progressCaption = new LabelWidget();
            progressCaption.Text = "充能进度";
            progressCaption.Size = new Vector2(140.0f, 22.0f);
            root.Children.Add(progressCaption);
            root.SetWidgetPosition(progressCaption, new Vector2(145.0f, 48.0f));

            m_chargeBar = new ValueBarWidget();
            m_chargeBar.BarsCount = 20;
            m_chargeBar.Value = 0.0f;
            m_chargeBar.Size = new Vector2(145.0f, 22.0f);
            root.Children.Add(m_chargeBar);
            root.SetWidgetPosition(m_chargeBar, new Vector2(145.0f, 82.0f));

            LabelWidget energyCaption = new LabelWidget();
            energyCaption.Text = "晴天能量";
            energyCaption.Size = new Vector2(110.0f, 22.0f);
            root.Children.Add(energyCaption);
            root.SetWidgetPosition(energyCaption, new Vector2(302.0f, 48.0f));

            m_energyBar = new ValueBarWidget();
            m_energyBar.BarsCount = 20;
            m_energyBar.Value = 0.0f;
            m_energyBar.Size = new Vector2(105.0f, 22.0f);
            root.Children.Add(m_energyBar);
            root.SetWidgetPosition(m_energyBar, new Vector2(302.0f, 82.0f));

            m_statusLabel = new LabelWidget();
            m_statusLabel.Size = new Vector2(380.0f, 32.0f);
            root.Children.Add(m_statusLabel);
            root.SetWidgetPosition(m_statusLabel, new Vector2(22.0f, 160.0f));

            DialogWidget = root;
            RefreshWidgets();
        }

        public override void Update()
        {
            base.Update();
            RefreshWidgets();
        }

        private void RefreshWidgets()
        {
            float chargeValue = SunWeatherControllerConfig.ChargeSecondsPerFuel > 0.0f
                ? m_state.ChargeProgress / SunWeatherControllerConfig.ChargeSecondsPerFuel
                : 0.0f;
            float energyValue = m_state.Energy / SunWeatherControllerConfig.MaxEnergy;

            m_chargeBar.Value = Clamp01(chargeValue);
            m_energyBar.Value = Clamp01(energyValue);

            if (m_state.SlotCount <= 0)
            {
                m_statusLabel.Text = "请将钻石块放入左侧槽位。能量耗尽后天气恢复正常。";
            }
            else if (m_state.Energy <= 0.0f)
            {
                m_statusLabel.Text = "正在充能；充能完成后将自动开启晴天。";
            }
            else
            {
                m_statusLabel.Text = "晴天运行中。剩余能量：" + m_state.Energy.ToString("0.0") + " / " +
                    SunWeatherControllerConfig.MaxEnergy.ToString("0.0");
            }
        }

        private static float Clamp01(float value)
        {
            if (value < 0.0f) return 0.0f;
            if (value > 1.0f) return 1.0f;
            return value;
        }

        private static void AssignInventorySlot(InventorySlotWidget widget, IInventory inventory, int slotIndex)
        {
            MethodInfo method = typeof(InventorySlotWidget).GetMethod(
                "AssignInventorySlot", BindingFlags.Instance | BindingFlags.Public);
            if (method == null)
                throw new MissingMethodException(typeof(InventorySlotWidget).FullName, "AssignInventorySlot");

            ParameterInfo[] parameters = method.GetParameters();
            object indexValue = slotIndex;
            if (parameters.Length > 1)
            {
                Type indexType = parameters[1].ParameterType;
                if (indexType.IsEnum)
                    indexValue = Enum.ToObject(indexType, slotIndex);
                else if (indexType != typeof(int))
                    indexValue = Convert.ChangeType(slotIndex, indexType);
            }

            method.Invoke(widget, new object[] { inventory, indexValue });
        }
    }
}

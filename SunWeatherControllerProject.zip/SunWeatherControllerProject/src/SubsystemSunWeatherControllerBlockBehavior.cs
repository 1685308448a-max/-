using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using GameEntitySystem;

namespace Game
{
    /// <summary>
    /// 晴天控制器的核心子系统。
    /// 该类型既是 SubsystemBlockBehavior（接收方块放置/拆除/交互事件），
    /// 又实现 IUpdateable（持续充能、耗能并控制天气）。
    /// </summary>
    public sealed class SubsystemSunWeatherControllerBlockBehavior : SubsystemBlockBehavior, IUpdateable
    {
        private const string StatesKey = "SunWeatherControllerStates";
        private const string WeatherSnapshotKey = "SunWeatherControllerWeatherSnapshot";

        private readonly Dictionary<string, ControllerState> m_states = new Dictionary<string, ControllerState>();

        private SubsystemInventory m_subsystemInventory;
        private SubsystemPickables m_subsystemPickables;
        private SubsystemWeather m_subsystemWeather;
        private int m_controllerContents = -1;
        private int m_fuelContents = -1;
        private WeatherSnapshot m_weatherSnapshot;

        public int UpdateOrder
        {
            get { return SunWeatherControllerConfig.UpdateOrder; }
        }

        public override int[] HandledBlocks
        {
            get
            {
                EnsureBlockIds();
                return new int[] { m_controllerContents };
            }
        }

        public override void Load(ValuesDictionary valuesDictionary)
        {
            base.Load(valuesDictionary);

            EnsureBlockIds();
            m_subsystemInventory = Project.FindSubsystem<SubsystemInventory>(true);
            m_subsystemPickables = Project.FindSubsystem<SubsystemPickables>(true);
            m_subsystemWeather = Project.FindSubsystem<SubsystemWeather>(true);

            m_states.Clear();
            string stateText = valuesDictionary.GetValue<string>(StatesKey, string.Empty);
            if (!string.IsNullOrEmpty(stateText))
            {
                string[] lines = stateText.Split(';');
                for (int i = 0; i < lines.Length; i++)
                {
                    ControllerState state;
                    if (ControllerState.TryParseSaveLine(
                        lines[i], m_subsystemInventory, m_fuelContents, m_subsystemPickables, out state))
                    {
                        m_states[MakeKey(state.X, state.Y, state.Z)] = state;
                    }
                }
            }

            m_weatherSnapshot = WeatherSnapshot.TryParse(
                valuesDictionary.GetValue<string>(WeatherSnapshotKey, string.Empty));
        }

        public override void Save(ValuesDictionary valuesDictionary)
        {
            base.Save(valuesDictionary);
            valuesDictionary.SetValue<string>(StatesKey, SerializeStates());
            valuesDictionary.SetValue<string>(
                WeatherSnapshotKey,
                m_weatherSnapshot == null ? string.Empty : m_weatherSnapshot.Serialize());
        }

        public override void OnBlockAdded(int value, int oldValue, int x, int y, int z)
        {
            base.OnBlockAdded(value, oldValue, x, y, z);
            EnsureBlockIds();

            if (Terrain.ExtractContents(value) == m_controllerContents)
            {
                EnsureState(x, y, z);
            }
        }

        public override void OnBlockRemoved(int value, int newValue, int x, int y, int z)
        {
            base.OnBlockRemoved(value, newValue, x, y, z);
            EnsureBlockIds();

            if (Terrain.ExtractContents(value) == m_controllerContents &&
                Terrain.ExtractContents(newValue) != m_controllerContents)
            {
                RemoveState(x, y, z);
            }
        }

        public override void OnBlockGenerated(int value, int x, int y, int z, bool isLoaded)
        {
            base.OnBlockGenerated(value, x, y, z, isLoaded);
            EnsureBlockIds();

            if (Terrain.ExtractContents(value) == m_controllerContents)
            {
                EnsureState(x, y, z);
            }
        }

        public override bool OnInteract(TerrainRaycastResult raycastResult, ComponentMiner componentMiner)
        {
            EnsureBlockIds();
            int x = raycastResult.CellFace.X;
            int y = raycastResult.CellFace.Y;
            int z = raycastResult.CellFace.Z;

            ControllerState state = EnsureState(x, y, z);
            DialogsManager.ShowDialog(new SunWeatherControllerDialog(state));
            return true;
        }

        public void Update(float dt)
        {
            if (m_subsystemWeather == null)
                return;

            // 防止读档或切换世界时出现异常大 dt，造成能量一帧清空。
            if (dt < 0.0f)
                dt = 0.0f;
            if (dt > 1.0f)
                dt = 1.0f;

            bool anyPoweredController = false;
            foreach (ControllerState state in m_states.Values)
            {
                // 只有能量低于“上限 - 单次燃料收益”时才开始下一轮充能，
                // 避免在接近满能量时连续消耗燃料却只得到很少的有效能量。
                float chargeThreshold = SunWeatherControllerConfig.MaxEnergy -
                    SunWeatherControllerConfig.EnergyPerFuel;

                if (state.Inventory.GetSlotCount(0) > 0 && state.Energy <= chargeThreshold)
                {
                    state.ChargeProgress += dt;
                    if (state.ChargeProgress >= SunWeatherControllerConfig.ChargeSecondsPerFuel)
                    {
                        if (state.Inventory.ConsumeOneFuel())
                        {
                            state.Energy = Math.Min(
                                SunWeatherControllerConfig.MaxEnergy,
                                state.Energy + SunWeatherControllerConfig.EnergyPerFuel);
                        }
                        state.ChargeProgress = 0.0f;
                    }
                }
                else
                {
                    state.ChargeProgress = 0.0f;
                }

                if (state.Energy > 0.0f)
                {
                    state.Energy = Math.Max(
                        0.0f,
                        state.Energy - SunWeatherControllerConfig.EnergyDrainPerSecond * dt);
                }

                if (state.Energy > 0.0001f)
                    anyPoweredController = true;
            }

            if (anyPoweredController)
            {
                if (m_weatherSnapshot == null)
                    m_weatherSnapshot = WeatherSnapshot.Capture(m_subsystemWeather);

                WeatherSnapshot.ForceSunny(m_subsystemWeather);
            }
            else
            {
                // 无能量时恢复控制器接管前的天气时间、降水、闪电及雨声参数。
                if (m_weatherSnapshot != null)
                {
                    m_weatherSnapshot.Restore(m_subsystemWeather);
                    m_weatherSnapshot = null;
                }
            }
        }

        private void EnsureBlockIds()
        {
            if (m_controllerContents < 0)
            {
                Block controllerBlock = BlocksManager.FindBlockByTypeName("SunWeatherControllerBlock", true);
                m_controllerContents = controllerBlock.BlockIndex;
            }

            if (m_fuelContents < 0)
            {
                Block fuelBlock = BlocksManager.FindBlockByTypeName(
                    SunWeatherControllerConfig.FuelBlockTypeName, true);
                m_fuelContents = fuelBlock.BlockIndex;
            }
        }

        private ControllerState EnsureState(int x, int y, int z)
        {
            string key = MakeKey(x, y, z);
            ControllerState state;
            if (m_states.TryGetValue(key, out state))
                return state;

            state = new ControllerState(
                x, y, z,
                0.0f,
                0.0f,
                0,
                0,
                m_subsystemInventory,
                m_fuelContents,
                m_subsystemPickables);
            m_states.Add(key, state);
            return state;
        }

        private void RemoveState(int x, int y, int z)
        {
            string key = MakeKey(x, y, z);
            ControllerState state;
            if (!m_states.TryGetValue(key, out state))
                return;

            // 拆除控制器时，将槽位里尚未使用的燃料掉落在方块位置。
            state.Inventory.DropAllItems(new Engine.Vector3(x + 0.5f, y + 0.5f, z + 0.5f));
            m_states.Remove(key);
        }

        private string SerializeStates()
        {
            StringBuilder builder = new StringBuilder();
            foreach (ControllerState state in m_states.Values)
            {
                if (builder.Length > 0)
                    builder.Append(';');
                builder.Append(state.ToSaveLine());
            }
            return builder.ToString();
        }

        private static string MakeKey(int x, int y, int z)
        {
            return x.ToString(CultureInfo.InvariantCulture) + "," +
                   y.ToString(CultureInfo.InvariantCulture) + "," +
                   z.ToString(CultureInfo.InvariantCulture);
        }
    }
}

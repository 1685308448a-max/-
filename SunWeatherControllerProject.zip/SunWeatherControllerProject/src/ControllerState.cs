using System;
using System.Globalization;

namespace Game
{
    /// <summary>
    /// 每一个已放置的晴天控制器对应一份独立状态。
    /// </summary>
    internal sealed class ControllerState
    {
        public readonly int X;
        public readonly int Y;
        public readonly int Z;

        public float Energy;
        public float ChargeProgress;
        public int SlotValue;
        public int SlotCount;
        public OneSlotInventory Inventory;

        public ControllerState(
            int x,
            int y,
            int z,
            float energy,
            float chargeProgress,
            int slotValue,
            int slotCount,
            SubsystemInventory subsystemInventory,
            int fuelContents,
            object subsystemPickables)
        {
            X = x;
            Y = y;
            Z = z;
            Energy = Clamp(energy, 0.0f, SunWeatherControllerConfig.MaxEnergy);
            ChargeProgress = Clamp(chargeProgress, 0.0f, SunWeatherControllerConfig.ChargeSecondsPerFuel);
            SlotValue = slotValue;
            SlotCount = Math.Max(0, Math.Min(SunWeatherControllerConfig.FuelSlotCapacity, slotCount));
            Inventory = new OneSlotInventory(this, subsystemInventory, fuelContents, subsystemPickables);

            if (SlotCount == 0)
                SlotValue = 0;
        }

        public string ToSaveLine()
        {
            return string.Join(",", new string[]
            {
                X.ToString(CultureInfo.InvariantCulture),
                Y.ToString(CultureInfo.InvariantCulture),
                Z.ToString(CultureInfo.InvariantCulture),
                Energy.ToString("R", CultureInfo.InvariantCulture),
                ChargeProgress.ToString("R", CultureInfo.InvariantCulture),
                SlotValue.ToString(CultureInfo.InvariantCulture),
                SlotCount.ToString(CultureInfo.InvariantCulture)
            });
        }

        public static bool TryParseSaveLine(
            string line,
            SubsystemInventory subsystemInventory,
            int fuelContents,
            object subsystemPickables,
            out ControllerState state)
        {
            state = null;
            if (string.IsNullOrEmpty(line))
                return false;

            string[] parts = line.Split(',');
            if (parts.Length != 7)
                return false;

            int x, y, z, slotValue, slotCount;
            float energy, progress;
            if (!int.TryParse(parts[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out x) ||
                !int.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out y) ||
                !int.TryParse(parts[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out z) ||
                !float.TryParse(parts[3], NumberStyles.Float, CultureInfo.InvariantCulture, out energy) ||
                !float.TryParse(parts[4], NumberStyles.Float, CultureInfo.InvariantCulture, out progress) ||
                !int.TryParse(parts[5], NumberStyles.Integer, CultureInfo.InvariantCulture, out slotValue) ||
                !int.TryParse(parts[6], NumberStyles.Integer, CultureInfo.InvariantCulture, out slotCount))
                return false;

            state = new ControllerState(
                x, y, z, energy, progress, slotValue, slotCount,
                subsystemInventory, fuelContents, subsystemPickables);
            return true;
        }

        private static float Clamp(float value, float min, float max)
        {
            if (value < min) return min;
            if (value > max) return max;
            return value;
        }
    }
}

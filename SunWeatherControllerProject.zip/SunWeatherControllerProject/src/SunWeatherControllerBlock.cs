using Engine;

namespace Game
{
    /// <summary>
    /// 晴天控制器方块本体。方块显示名称、分类和纹理由 ContentPatch/Blocks.csv.fragment 提供。
    /// </summary>
    public class SunWeatherControllerBlock : CubeBlock
    {
        public SunWeatherControllerBlock()
        {
        }
    }
}

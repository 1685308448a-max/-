namespace Game
{
    /// <summary>
    /// 晴天控制器参数。可直接修改这些常量来调整燃料、充能速度和耗电速度。
    /// </summary>
    internal static class SunWeatherControllerConfig
    {
        // 默认投入槽位的方块。此 APK 的 Survivalcraft.dll 中确认存在 DiamondBlock。
        public const string FuelBlockTypeName = "DiamondBlock";

        // 单个燃料方块增加的能量值。
        public const float EnergyPerFuel = 25.0f;

        // 能量上限。
        public const float MaxEnergy = 100.0f;

        // 消耗一个燃料方块所需的充能时间（秒）。
        public const float ChargeSecondsPerFuel = 8.0f;

        // 晴天运行时每秒消耗的能量值。
        public const float EnergyDrainPerSecond = 0.05f;

        // 输入槽允许的最大堆叠数量。
        public const int FuelSlotCapacity = 64;

        // 更新顺序设置得较高，使控制器尽量在天气系统更新之后执行。
        public const int UpdateOrder = 10000;
    }
}
